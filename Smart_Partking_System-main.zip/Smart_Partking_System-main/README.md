# Smart_Partking_System
Intership Projoct
In This Project , You can Manage the Parking System very efficiently by using IOT technology.
To Make this Project We Need Some Component.

  HARDWARE:-

  1.Arduino
  
  2.NodeMCU
  
  3.IR Senser
  
  4.Servo Motor
  
  5.Jumber Wires
  
  6.Power Source

  SOFTWARE:-
  
  1.Arduino Sketch IDE
  
  2.Blynk App or Dashboard
  
  3.Fritzing 8

I have some Screenshot of Blynk , You can refer
